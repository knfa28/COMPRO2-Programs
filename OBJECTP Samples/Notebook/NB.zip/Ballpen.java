public class Ballpen
{
   public static void write( Notebook n, String text )
   {
      n.write( text );
   }
}